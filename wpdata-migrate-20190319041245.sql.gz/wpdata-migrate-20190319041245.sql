# WordPress MySQL database migration
#
# Generated: Tuesday 19. March 2019 04:12 UTC
# Hostname: localhost
# Database: `wpdata`
# URL: //localhost/stephanie
# Path: /Applications/MAMP/htdocs/stephanie
# Tables: wp_cfs_sessions, wp_cfs_values, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, cfs, custom_css, customize_changeset, nav_menu_item, page, post, product
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cfs_sessions`
#

DROP TABLE IF EXISTS `wp_cfs_sessions`;


#
# Table structure of table `wp_cfs_sessions`
#

CREATE TABLE `wp_cfs_sessions` (
  `id` varchar(32) NOT NULL,
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_sessions`
#
INSERT INTO `wp_cfs_sessions` ( `id`, `data`, `expires`) VALUES
('03a89d896d65c80b3f38eaa58bb814bd', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280772'),
('0c42c0322cf2aa49460a478c79ef51da', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279835'),
('1299b4dc9c26d60cffa1b47d9787f321', 'a:7:{s:7:"post_id";i:91;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552287929'),
('149617cbb8ff36cd38af57885a11af88', 'a:7:{s:7:"post_id";i:180;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280572'),
('1c1916e9330805106687c6a02741d7b3', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280533'),
('28b70deb2ecf7358173f54091f007c90', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280118'),
('29171c2c432e4ecac7cd359fbd3700be', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279798'),
('469f9ed5ca93ac0ccb07b9c8ee0a5560', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279949'),
('4a4e419b4c449d7515bf8cb08ae3740e', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280527'),
('592d851e503b9ca08b25fe269bc1e59d', 'a:7:{s:7:"post_id";i:181;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280351'),
('7122de2da587feb7efe2eb406a228a49', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280189'),
('7153ae40bd8e84423839d69c4c12b0d7', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280691'),
('77e698fc7a2229d4d8ff118ff9d359f0', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279291'),
('8abb64c8b191fb38df327ed83f81ac42', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279878'),
('950eaee89386fb524d3f9e04d5934a43', 'a:7:{s:7:"post_id";i:180;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280342'),
('9c0cbab2b0b90cbb4637134b8a3c62be', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280160'),
('ac9e9f95295d31359159e80dd494b751', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280356'),
('c39c0c51f5ca2f74fbfdd0c601e0f985', 'a:7:{s:7:"post_id";i:180;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280733'),
('d70ea9a9a4a9caf18622f66adcee0d41', 'a:7:{s:7:"post_id";i:180;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280226'),
('dcb47ff84f306f9618ca9d67e2622e17', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279177'),
('e67a42eb85bd9c370791d844dba5d52e', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280753'),
('ed789ddbf2165c892f2027c70dd29329', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280445'),
('f152cd0bc8c2f69e88d6784d1efce563', 'a:7:{s:7:"post_id";i:182;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552280716'),
('f1ada2b98700c7504729a68263c7241b', 'a:7:{s:7:"post_id";i:174;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:7;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1552279760') ;

#
# End of data contents of table `wp_cfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_cfs_values`
#

DROP TABLE IF EXISTS `wp_cfs_values`;


#
# Table structure of table `wp_cfs_values`
#

CREATE TABLE `wp_cfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_values`
#
INSERT INTO `wp_cfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(44, 1, 314, 118, 0, '', 0, 0, 0),
(47, 1, 392, 91, 0, '', 0, 0, 0),
(50, 1, 395, 90, 0, '', 0, 0, 0),
(52, 1, 397, 87, 0, '', 0, 0, 0),
(53, 1, 398, 78, 0, '', 0, 0, 0),
(54, 1, 399, 77, 0, '', 0, 0, 0),
(58, 1, 403, 89, 0, '', 0, 0, 0),
(60, 1, 405, 84, 0, '', 0, 0, 0),
(62, 1, 407, 76, 0, '', 0, 0, 0),
(63, 1, 408, 73, 0, '', 0, 0, 0),
(64, 1, 409, 88, 0, '', 0, 0, 0),
(65, 1, 410, 86, 0, '', 0, 0, 0),
(66, 1, 411, 85, 0, '', 0, 0, 0),
(67, 1, 412, 83, 0, '', 0, 0, 0),
(69, 1, 414, 81, 0, '', 0, 0, 0),
(70, 1, 415, 80, 0, '', 0, 0, 0),
(71, 1, 416, 79, 0, '', 0, 0, 0),
(77, 1, 445, 174, 0, '', 0, 0, 0),
(78, 1, 450, 180, 0, '', 0, 0, 0),
(80, 1, 463, 182, 0, '', 0, 0, 0) ;

#
# End of data contents of table `wp_cfs_values`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-02-20 21:47:20', '2019-02-20 21:47:20', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=863 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/stephanie', 'yes'),
(2, 'home', 'http://localhost/stephanie', 'yes'),
(3, 'blogname', 'Inhabitent', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'stephanie133.tait@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:132:{s:10:"product/?$";s:27:"index.php?post_type=product";s:40:"product/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:35:"product/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:27:"product/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:57:"new_product_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?new_product_type=$matches[1]&feed=$matches[2]";s:52:"new_product_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?new_product_type=$matches[1]&feed=$matches[2]";s:33:"new_product_type/([^/]+)/embed/?$";s:49:"index.php?new_product_type=$matches[1]&embed=true";s:45:"new_product_type/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?new_product_type=$matches[1]&paged=$matches[2]";s:27:"new_product_type/([^/]+)/?$";s:38:"index.php?new_product_type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:40:"index.php?&page_id=138&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:26:"custom-field-suite/cfs.php";i:1;s:46:"red-functionality-master/red-functionality.php";i:2;s:56:"red-widget-boilerplate-master/red-widget-boilerplate.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'redstarter-master', 'yes'),
(41, 'stylesheet', 'redstarter-master', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '138', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '116', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{s:12:"_multiwidget";i:1;i:3;a:0:{}}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:13:"custom_html-3";i:1;s:16:"business-hours-2";i:2;s:10:"archives-3";}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'nonce_key', '|VIBpGk~;klJoWYWGJ{9`aKmX<bgJs?%H4tZfpoco-}h y<12Y0{T~oaw1PX3B%H', 'no'),
(109, 'nonce_salt', '3C1f@d`Eha&AqI]`/|G_kV72-CP00^^Mr<&iEz{V6QHA&w2XpkDYU3S!;+/wR&]y', 'no'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:2:{s:12:"_multiwidget";i:1;i:3;a:2:{s:5:"title";s:12:"Contact Info";s:7:"content";s:391:"<p><i class="fa fa-envelope"></i><a href="mailto:info@inhabitent.com">info@inhabitent.com</a></p>\r\n							<p><i class="fa fa-phone"></i><a href="tel:5553434567891">778-456-7891</a></p>\r\n							<p>\r\n								<span><i class="fa fa-facebook-square"></i></span>\r\n								<span><i class="fa fa-twitter-square"></i></span>\r\n								<span><i class="fa fa-google-plus-square"></i></span>\r\n							</p>";}}', 'yes'),
(113, 'cron', 'a:5:{i:1552970841;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1552988841;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1553032082;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1553032251;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(114, 'theme_mods_twentynineteen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1550699290;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(115, 'logged_in_key', '+luR0,J+x<2[;Tmi8(q+.~P$MZ4}P,`t)aPSnbT6+;Dpx?ogYwootk=UCh)+2CoG', 'no'),
(116, 'logged_in_salt', 'H.Z6GceYqcxsjzl2N*]DsO7&[v<sg5y.9{Y|o6t=D/A:H{u+H}^t{p RYzI?%_Rx', 'no'),
(125, 'auth_key', '(3v2@q6X;i~X3Q6 s2xVdmfP~3#|:y&^WmtO;<y&.1r?kQ.`:tJ7sl,aXS*yl0T*', 'no'),
(126, 'auth_salt', 'a1VUV?O(L59f}m)-<XRb,&=`VF6z@uF}r)*min{#N0W9$)6lz,3E]s+[:wAFTJA7', 'no'),
(142, 'can_compress_scripts', '1', 'no'),
(143, 'current_theme', 'RED Starter Theme', 'yes'),
(144, 'theme_mods_redstarter-master', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:18:"custom_css_post_id";i:134;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1551597751;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}}}}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(168, 'cfs_next_field_id', '2', 'yes'),
(169, 'cfs_version', '2.5.12', 'yes'),
(199, 'theme_mods_twentyseventeen', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:3:"top";i:2;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1551597912;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:0:{}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(204, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(350, 'widget_bsuiness-hours', 'a:2:{i:3;a:4:{s:5:"title";s:14:"Business Hours";s:13:"monday_friday";s:10:"9am to 5pm";s:8:"saturday";s:11:"10am to 2pm";s:6:"sunday";s:6:"Closed";}s:12:"_multiwidget";i:1;}', 'yes'),
(576, 'category_children', 'a:0:{}', 'yes'),
(608, 'widget_business-hours', 'a:2:{i:2;a:4:{s:5:"title";s:14:"Business Hours";s:13:"monday_friday";s:10:"9am to 5pm";s:8:"saturday";s:11:"10am to 2pm";s:6:"sunday";s:6:"Closed";}s:12:"_multiwidget";i:1;}', 'yes'),
(783, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:27:"stephanie133.tait@gmail.com";s:7:"version";s:5:"5.0.4";s:9:"timestamp";i:1552569975;}', 'no'),
(860, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1552968765;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=483 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 7, '_edit_last', '1'),
(6, 7, '_edit_lock', '1550775940:1'),
(7, 7, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";i:1;s:4:"name";s:5:"price";s:5:"label";s:6:"Price ";s:4:"type";s:4:"text";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"0";}}}'),
(8, 7, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:7:"product";}}}'),
(9, 7, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(10, 8, '_edit_lock', '1551130428:1'),
(11, 9, '_edit_lock', '1552251180:1'),
(39, 14, '_edit_lock', '1550956972:1'),
(48, 2, '_edit_lock', '1551595172:1'),
(49, 14, '_wp_page_template', 'default'),
(50, 17, '_wp_attached_file', '2019/02/beach-bonfire.jpg'),
(51, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:25:"2019/02/beach-bonfire.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"beach-bonfire-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"beach-bonfire-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"beach-bonfire-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"beach-bonfire-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(52, 18, '_wp_attached_file', '2019/02/canoe-girl.jpg'),
(53, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:22:"2019/02/canoe-girl.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"canoe-girl-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"canoe-girl-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"canoe-girl-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"canoe-girl-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(54, 19, '_wp_attached_file', '2019/02/mountain-hikers.jpg'),
(55, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:27:"2019/02/mountain-hikers.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"mountain-hikers-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"mountain-hikers-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"mountain-hikers-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"mountain-hikers-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(56, 20, '_wp_attached_file', '2019/02/night-sky.jpg'),
(57, 20, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:21:"2019/02/night-sky.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"night-sky-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"night-sky-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"night-sky-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"night-sky-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(58, 21, '_wp_attached_file', '2019/02/about-hero.jpg'),
(59, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2019/02/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(60, 22, '_wp_attached_file', '2019/02/glamping.jpg'),
(61, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2019/02/glamping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"glamping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"glamping-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"glamping-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"glamping-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(62, 23, '_wp_attached_file', '2019/02/healthy-camp-food.jpg'),
(63, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:29:"2019/02/healthy-camp-food.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"healthy-camp-food-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"healthy-camp-food-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"healthy-camp-food-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"healthy-camp-food-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(64, 24, '_wp_attached_file', '2019/02/solo-camping.jpg'),
(65, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:24:"2019/02/solo-camping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"solo-camping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"solo-camping-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"solo-camping-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"solo-camping-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(66, 25, '_wp_attached_file', '2019/02/van-camper.jpg'),
(67, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:22:"2019/02/van-camper.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"van-camper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"van-camper-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"van-camper-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"van-camper-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(68, 26, '_wp_attached_file', '2019/02/warm-cocktail.jpg'),
(69, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:25:"2019/02/warm-cocktail.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"warm-cocktail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"warm-cocktail-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"warm-cocktail-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"warm-cocktail-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(70, 27, '_wp_attached_file', '2019/02/beach-tent.jpg'),
(71, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:22:"2019/02/beach-tent.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"beach-tent-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"beach-tent-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"beach-tent-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"beach-tent-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(72, 28, '_wp_attached_file', '2019/02/camper-van.jpg'),
(73, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:22:"2019/02/camper-van.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"camper-van-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"camper-van-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"camper-van-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"camper-van-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(74, 29, '_wp_attached_file', '2019/02/ceramic-mugs.jpg'),
(75, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:24:"2019/02/ceramic-mugs.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"ceramic-mugs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"ceramic-mugs-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"ceramic-mugs-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"ceramic-mugs-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(76, 30, '_wp_attached_file', '2019/02/film-cameras.jpg'),
(77, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2019/02/film-cameras.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"film-cameras-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"film-cameras-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"film-cameras-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"film-cameras-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(78, 31, '_wp_attached_file', '2019/02/flannel-shirt.jpg'),
(79, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2019/02/flannel-shirt.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"flannel-shirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"flannel-shirt-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"flannel-shirt-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"flannel-shirt-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(80, 32, '_wp_attached_file', '2019/02/gas-stove.jpg'),
(81, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:21:"2019/02/gas-stove.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"gas-stove-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"gas-stove-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"gas-stove-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"gas-stove-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(82, 33, '_wp_attached_file', '2019/02/hand-knit-toque.jpg'),
(83, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:27:"2019/02/hand-knit-toque.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hand-knit-toque-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"hand-knit-toque-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"hand-knit-toque-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"hand-knit-toque-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(84, 34, '_wp_attached_file', '2019/02/hiking-boots.jpg'),
(85, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:24:"2019/02/hiking-boots.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"hiking-boots-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"hiking-boots-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"hiking-boots-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"hiking-boots-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(86, 35, '_wp_attached_file', '2019/02/large-thermos.jpg'),
(87, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2019/02/large-thermos.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"large-thermos-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"large-thermos-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"large-thermos-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"large-thermos-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(88, 36, '_wp_attached_file', '2019/02/leather-satchel.jpg'),
(89, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2019/02/leather-satchel.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"leather-satchel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"leather-satchel-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"leather-satchel-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"leather-satchel-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 37, '_wp_attached_file', '2019/02/nylon-tents.jpg'),
(91, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:23:"2019/02/nylon-tents.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"nylon-tents-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"nylon-tents-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"nylon-tents-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"nylon-tents-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(92, 38, '_wp_attached_file', '2019/02/rustic-tools.jpg'),
(93, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:24:"2019/02/rustic-tools.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"rustic-tools-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"rustic-tools-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"rustic-tools-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"rustic-tools-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(94, 39, '_wp_attached_file', '2019/02/stew-can.jpg'),
(95, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2019/02/stew-can.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"stew-can-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"stew-can-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"stew-can-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"stew-can-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(96, 40, '_wp_attached_file', '2019/02/travel-hammock.jpg'),
(97, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:26:"2019/02/travel-hammock.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"travel-hammock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"travel-hammock-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"travel-hammock-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"travel-hammock-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(98, 41, '_wp_attached_file', '2019/02/weathered-canoes.jpg'),
(99, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:28:"2019/02/weathered-canoes.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"weathered-canoes-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"weathered-canoes-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"weathered-canoes-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"weathered-canoes-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(100, 42, '_wp_attached_file', '2019/02/wood-ax.jpg'),
(101, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:19:"2019/02/wood-ax.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"wood-ax-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"wood-ax-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"wood-ax-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"wood-ax-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(102, 43, '_edit_lock', '1551597284:1'),
(103, 44, '_menu_item_type', 'post_type'),
(104, 44, '_menu_item_menu_item_parent', '0'),
(105, 44, '_menu_item_object_id', '43'),
(106, 44, '_menu_item_object', 'page'),
(107, 44, '_menu_item_target', ''),
(108, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(109, 44, '_menu_item_xfn', ''),
(110, 44, '_menu_item_url', ''),
(111, 43, '_wp_page_template', 'about.php'),
(112, 46, '_edit_lock', '1551071573:1'),
(113, 48, '_wp_attached_file', '2019/02/home-hero.jpg'),
(114, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2404;s:4:"file";s:21:"2019/02/home-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"home-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"home-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"home-hero-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"home-hero-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(115, 1, '_edit_lock', '1551071560:1'),
(116, 46, '_wp_trash_meta_status', 'draft'),
(117, 46, '_wp_trash_meta_time', '1551071718'),
(118, 46, '_wp_desired_post_slug', ''),
(120, 52, '_edit_lock', '1551634418:1'),
(121, 52, '_thumbnail_id', '18'),
(123, 54, '_edit_lock', '1551201533:1'),
(125, 54, '_thumbnail_id', '17'),
(126, 1, '_wp_trash_meta_status', 'publish'),
(127, 1, '_wp_trash_meta_time', '1551074705'),
(128, 1, '_wp_desired_post_slug', 'hello-world'),
(129, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(130, 57, '_edit_lock', '1551671748:1'),
(131, 57, '_thumbnail_id', '19'),
(134, 61, '_edit_lock', '1551201433:1'),
(135, 61, '_thumbnail_id', '20'),
(138, 14, '_wp_trash_meta_status', 'publish'),
(139, 14, '_wp_trash_meta_time', '1551076695'),
(140, 14, '_wp_desired_post_slug', 'test'),
(141, 64, '_edit_lock', '1551128014:1'),
(152, 25, '_edit_lock', '1551131240:1'),
(153, 25, '_edit_last', '1'),
(155, 70, '_edit_lock', '1551150925:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(156, 70, '_thumbnail_id', '27'),
(159, 8, '_wp_trash_meta_status', 'draft'),
(160, 8, '_wp_trash_meta_time', '1551151150'),
(161, 8, '_wp_desired_post_slug', ''),
(162, 73, '_edit_lock', '1551673414:1'),
(164, 73, '_edit_last', '1'),
(165, 73, '_thumbnail_id', '27'),
(167, 70, '_wp_trash_meta_status', 'publish'),
(168, 70, '_wp_trash_meta_time', '1551151507'),
(169, 70, '_wp_desired_post_slug', 'beach-tent'),
(170, 76, '_edit_lock', '1551673380:1'),
(172, 76, '_edit_last', '1'),
(174, 77, '_edit_lock', '1551672961:1'),
(176, 77, '_edit_last', '1'),
(177, 77, '_thumbnail_id', '29'),
(180, 76, '_thumbnail_id', '28'),
(182, 78, '_edit_lock', '1551672896:1'),
(183, 78, '_thumbnail_id', '30'),
(185, 78, '_edit_last', '1'),
(187, 79, '_edit_lock', '1551673732:1'),
(188, 79, '_thumbnail_id', '31'),
(190, 79, '_edit_last', '1'),
(192, 80, '_edit_lock', '1551673700:1'),
(194, 80, '_edit_last', '1'),
(195, 80, '_thumbnail_id', '32'),
(206, 81, '_edit_lock', '1551673669:1'),
(207, 81, '_thumbnail_id', '33'),
(209, 81, '_edit_last', '1'),
(212, 83, '_edit_lock', '1551673548:1'),
(213, 83, '_thumbnail_id', '34'),
(215, 83, '_edit_last', '1'),
(217, 84, '_edit_lock', '1551673318:1'),
(218, 84, '_thumbnail_id', '35'),
(220, 84, '_edit_last', '1'),
(222, 85, '_edit_lock', '1551673520:1'),
(223, 85, '_thumbnail_id', '36'),
(225, 85, '_edit_last', '1'),
(227, 86, '_edit_lock', '1551673481:1'),
(228, 86, '_thumbnail_id', '37'),
(230, 86, '_edit_last', '1'),
(232, 87, '_edit_lock', '1551672868:1'),
(233, 87, '_thumbnail_id', '38'),
(235, 87, '_edit_last', '1'),
(237, 88, '_edit_lock', '1551673448:1'),
(238, 88, '_thumbnail_id', '39'),
(240, 88, '_edit_last', '1'),
(242, 89, '_edit_lock', '1551673247:1'),
(243, 89, '_thumbnail_id', '40'),
(245, 89, '_edit_last', '1'),
(247, 90, '_edit_lock', '1551672825:1'),
(248, 90, '_thumbnail_id', '41'),
(250, 90, '_edit_last', '1'),
(252, 91, '_edit_lock', '1552273770:1'),
(253, 91, '_thumbnail_id', '42'),
(255, 91, '_edit_last', '1'),
(258, 93, '_edit_lock', '1551155838:1'),
(260, 93, '_thumbnail_id', '25'),
(261, 95, '_edit_lock', '1551156025:1'),
(262, 95, '_thumbnail_id', '26'),
(264, 97, '_edit_lock', '1551158553:1'),
(265, 97, '_thumbnail_id', '23'),
(267, 99, '_edit_lock', '1551158263:1'),
(268, 99, '_thumbnail_id', '24'),
(270, 101, '_edit_lock', '1551158207:1'),
(271, 101, '_thumbnail_id', '22'),
(275, 106, '_menu_item_type', 'post_type'),
(276, 106, '_menu_item_menu_item_parent', '0'),
(277, 106, '_menu_item_object_id', '9'),
(278, 106, '_menu_item_object', 'page'),
(279, 106, '_menu_item_target', ''),
(280, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(281, 106, '_menu_item_xfn', ''),
(282, 106, '_menu_item_url', ''),
(284, 43, '_edit_last', '1'),
(285, 108, '_edit_lock', '1552254236:1'),
(286, 109, '_menu_item_type', 'post_type'),
(287, 109, '_menu_item_menu_item_parent', '0'),
(288, 109, '_menu_item_object_id', '108'),
(289, 109, '_menu_item_object', 'page'),
(290, 109, '_menu_item_target', ''),
(291, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(292, 109, '_menu_item_xfn', ''),
(293, 109, '_menu_item_url', ''),
(294, 111, '_edit_lock', '1551729326:1'),
(295, 112, '_menu_item_type', 'post_type'),
(296, 112, '_menu_item_menu_item_parent', '0'),
(297, 112, '_menu_item_object_id', '111'),
(298, 112, '_menu_item_object', 'page'),
(299, 112, '_menu_item_target', ''),
(300, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(301, 112, '_menu_item_xfn', ''),
(302, 112, '_menu_item_url', ''),
(303, 111, '_wp_page_template', 'find-us.php'),
(305, 9, '_edit_last', '1'),
(306, 9, '_wp_page_template', 'shop.php'),
(307, 116, '_wp_attached_file', '2019/02/cropped-canoe-girl.jpg'),
(308, 116, '_wp_attachment_context', 'site-icon'),
(309, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:30:"2019/02/cropped-canoe-girl.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"cropped-canoe-girl-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"cropped-canoe-girl-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-270";a:4:{s:4:"file";s:30:"cropped-canoe-girl-270x270.jpg";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-192";a:4:{s:4:"file";s:30:"cropped-canoe-girl-192x192.jpg";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:10:"image/jpeg";}s:13:"site_icon-180";a:4:{s:4:"file";s:30:"cropped-canoe-girl-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"site_icon-32";a:4:{s:4:"file";s:28:"cropped-canoe-girl-32x32.jpg";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(310, 117, '_edit_lock', '1551159136:1'),
(311, 117, '_wp_trash_meta_status', 'publish') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(312, 117, '_wp_trash_meta_time', '1551159186'),
(313, 118, '_edit_lock', '1551193259:1'),
(314, 118, 'price', ''),
(315, 118, '_edit_last', '1'),
(317, 118, '_wp_trash_meta_status', 'draft'),
(318, 118, '_wp_trash_meta_time', '1551193409'),
(319, 118, '_wp_desired_post_slug', ''),
(320, 120, '_edit_lock', '1551201163:1'),
(321, 120, '_thumbnail_id', '23'),
(324, 123, '_wp_attached_file', '2019/02/dark-wood.png'),
(325, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:21:"2019/02/dark-wood.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"dark-wood-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"dark-wood-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(330, 128, '_wp_attached_file', '2019/02/home-hero-1.jpg'),
(331, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2404;s:4:"file";s:23:"2019/02/home-hero-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"home-hero-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"home-hero-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"home-hero-1-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"home-hero-1-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(332, 129, '_wp_attached_file', '2019/02/home-hero-2.jpg'),
(333, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2404;s:4:"file";s:23:"2019/02/home-hero-2.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"home-hero-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"home-hero-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"home-hero-2-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"home-hero-2-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(335, 132, '_edit_lock', '1551593888:1'),
(344, 132, '_wp_trash_meta_status', 'publish'),
(345, 132, '_wp_trash_meta_time', '1551593891'),
(346, 2, '_wp_trash_meta_status', 'publish'),
(347, 2, '_wp_trash_meta_time', '1551595320'),
(348, 2, '_wp_desired_post_slug', 'sample-page'),
(349, 137, '_wp_trash_meta_status', 'publish'),
(350, 137, '_wp_trash_meta_time', '1551595797'),
(351, 138, '_edit_lock', '1552960579:1'),
(360, 138, '_wp_page_template', 'front-page.php'),
(361, 141, '_wp_trash_meta_status', 'publish'),
(362, 141, '_wp_trash_meta_time', '1551596051'),
(363, 43, '_thumbnail_id', '21'),
(364, 108, '_wp_page_template', 'journal.php'),
(367, 144, '_edit_lock', '1551599024:1'),
(368, 144, '_wp_trash_meta_status', 'publish'),
(369, 144, '_wp_trash_meta_time', '1551599057'),
(371, 146, '_edit_lock', '1551630074:1'),
(372, 146, '_wp_page_template', 'product-type.php'),
(379, 52, '_wp_old_slug', 'adventure-getting-back-to-nature-in-a-canoe'),
(380, 150, '_edit_lock', '1552270848:1'),
(381, 150, '_wp_page_template', 'product-type-do.php'),
(383, 153, '_edit_lock', '1551670383:1'),
(384, 153, '_wp_page_template', 'product-type-eat.php'),
(386, 158, '_edit_lock', '1551670522:1'),
(387, 158, '_wp_page_template', 'product-type-sleep.php'),
(389, 161, '_edit_lock', '1551670578:1'),
(390, 161, '_wp_page_template', 'product-type-wear.php'),
(392, 91, 'price', '$40.00'),
(395, 90, 'price', '$400.00'),
(397, 87, 'price', '$100.00'),
(398, 78, 'price', '$150.00'),
(399, 77, 'price', '$19.00'),
(403, 89, 'price', '$75.00'),
(405, 84, 'price', '$42.00'),
(407, 76, 'price', '$2500.00'),
(408, 73, 'price', '$155.00'),
(409, 88, 'price', '$22.00'),
(410, 86, 'price', '$220.00'),
(411, 85, 'price', '$60.00'),
(412, 83, 'price', '$135.00'),
(414, 81, 'price', '$28.00'),
(415, 80, 'price', '$120.00'),
(416, 79, 'price', '$45.00'),
(427, 166, '_edit_lock', '1552198751:1'),
(429, 166, '_thumbnail_id', '31'),
(430, 168, '_edit_lock', '1552199018:1'),
(432, 168, '_thumbnail_id', '40'),
(433, 170, '_edit_lock', '1552198939:1'),
(435, 170, '_thumbnail_id', '39'),
(437, 174, '_edit_lock', '1552266254:1'),
(438, 174, '_thumbnail_id', '39'),
(440, 174, '_edit_last', '1'),
(445, 174, 'price', '$22.00'),
(448, 180, '_edit_lock', '1552266200:1'),
(449, 180, '_thumbnail_id', '40'),
(450, 180, 'price', '$75.00'),
(451, 180, '_edit_last', '1'),
(453, 182, '_edit_lock', '1552266315:1'),
(454, 182, '_thumbnail_id', '31'),
(456, 182, '_edit_last', '1'),
(457, 168, '_wp_trash_meta_status', 'publish'),
(458, 168, '_wp_trash_meta_time', '1552266068'),
(459, 168, '_wp_desired_post_slug', 'travel-hammock'),
(460, 89, '_wp_old_slug', 'travel-hammock__trashed'),
(461, 88, '_wp_old_slug', 'stew-can__trashed'),
(462, 79, '_wp_old_slug', 'flannel-shirt__trashed'),
(463, 182, 'price', '$45.00'),
(464, 182, '_wp_trash_meta_status', 'publish'),
(465, 182, '_wp_trash_meta_time', '1552271024'),
(466, 182, '_wp_desired_post_slug', 'flannel-shirt'),
(467, 180, '_wp_trash_meta_status', 'publish'),
(468, 180, '_wp_trash_meta_time', '1552271032'),
(469, 180, '_wp_desired_post_slug', 'travel-hammock'),
(473, 91, '_wp_old_slug', 'wood-axe__trashed'),
(474, 174, '_wp_trash_meta_status', 'publish'),
(475, 174, '_wp_trash_meta_time', '1552271052'),
(476, 174, '_wp_desired_post_slug', 'stew-can'),
(477, 170, '_wp_trash_meta_status', 'publish'),
(478, 170, '_wp_trash_meta_time', '1552273453'),
(479, 170, '_wp_desired_post_slug', 'stew-can'),
(480, 166, '_wp_trash_meta_status', 'publish'),
(481, 166, '_wp_trash_meta_time', '1552273458'),
(482, 166, '_wp_desired_post_slug', 'flannel-shirt') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-02-20 21:47:20', '2019-02-20 21:47:20', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-02-25 06:05:05', '2019-02-25 06:05:05', '', 0, 'http://localhost/stephanie/?p=1', 0, 'post', '', 1),
(2, 1, '2019-02-20 21:47:20', '2019-02-20 21:47:20', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/stephanie/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-03-03 06:42:00', '2019-03-03 06:42:00', '', 0, 'http://localhost/stephanie/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-02-20 21:47:20', '2019-02-20 21:47:20', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost/stephanie.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-02-20 21:47:20', '2019-02-20 21:47:20', '', 0, 'http://localhost/stephanie/?page_id=3', 0, 'page', '', 0),
(7, 1, '2019-02-21 19:07:58', '2019-02-21 19:07:58', '', 'Product Fields', '', 'publish', 'closed', 'closed', '', 'product-fields', '', '', '2019-02-21 19:07:58', '2019-02-21 19:07:58', '', 0, 'http://localhost/stephanie/?post_type=cfs&#038;p=7', 0, 'cfs', '', 0),
(8, 1, '2019-02-26 03:19:10', '2019-02-26 03:19:10', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2019-02-26 03:19:10', '2019-02-26 03:19:10', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=8', 0, 'product', '', 0),
(9, 1, '2019-02-22 05:17:07', '2019-02-22 05:17:07', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'products', '', '', '2019-03-03 16:14:32', '2019-03-03 16:14:32', '', 0, 'http://localhost/stephanie/?page_id=9', 0, 'page', '', 0),
(10, 1, '2019-02-22 05:17:07', '2019-02-22 05:17:07', 'igeisgesingsnnsenings Howdy yalll', 'hellomyWOROOOLD', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2019-02-22 05:17:07', '2019-02-22 05:17:07', '', 9, 'http://localhost/stephanie/9-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2019-02-23 21:18:09', '2019-02-23 21:18:09', '', 'test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2019-02-25 06:38:15', '2019-02-25 06:38:15', '', 0, 'http://localhost/stephanie/?page_id=14', 0, 'page', '', 0),
(16, 1, '2019-02-23 21:18:09', '2019-02-23 21:18:09', '', 'test', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2019-02-23 21:18:09', '2019-02-23 21:18:09', '', 14, 'http://localhost/stephanie/14-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2019-02-23 21:24:33', '2019-02-23 21:24:33', '', 'beach-bonfire', '', 'inherit', 'open', 'closed', '', 'beach-bonfire', '', '', '2019-02-23 21:24:33', '2019-02-23 21:24:33', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/beach-bonfire.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2019-02-23 21:24:35', '2019-02-23 21:24:35', '', 'canoe-girl', '', 'inherit', 'open', 'closed', '', 'canoe-girl', '', '', '2019-02-23 21:24:35', '2019-02-23 21:24:35', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/canoe-girl.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2019-02-23 21:24:37', '2019-02-23 21:24:37', '', 'mountain-hikers', '', 'inherit', 'open', 'closed', '', 'mountain-hikers', '', '', '2019-02-23 21:24:37', '2019-02-23 21:24:37', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/mountain-hikers.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2019-02-23 21:24:38', '2019-02-23 21:24:38', '', 'night-sky', '', 'inherit', 'open', 'closed', '', 'night-sky', '', '', '2019-02-23 21:24:38', '2019-02-23 21:24:38', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/night-sky.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2019-02-23 21:33:38', '2019-02-23 21:33:38', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero', '', '', '2019-02-23 21:33:38', '2019-02-23 21:33:38', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2019-02-23 21:34:05', '2019-02-23 21:34:05', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2019-02-23 21:34:05', '2019-02-23 21:34:05', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/glamping.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2019-02-23 21:34:06', '2019-02-23 21:34:06', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2019-02-23 21:34:06', '2019-02-23 21:34:06', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/healthy-camp-food.jpg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2019-02-23 21:34:08', '2019-02-23 21:34:08', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2019-02-23 21:34:08', '2019-02-23 21:34:08', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/solo-camping.jpg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2019-02-23 21:34:10', '2019-02-23 21:34:10', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2019-02-25 21:49:29', '2019-02-25 21:49:29', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/van-camper.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2019-02-23 21:34:11', '2019-02-23 21:34:11', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2019-02-23 21:34:11', '2019-02-23 21:34:11', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/warm-cocktail.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2019-02-23 21:34:54', '2019-02-23 21:34:54', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent', '', '', '2019-02-23 21:34:54', '2019-02-23 21:34:54', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/beach-tent.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2019-02-23 21:34:55', '2019-02-23 21:34:55', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van', '', '', '2019-02-23 21:34:55', '2019-02-23 21:34:55', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/camper-van.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2019-02-23 21:34:56', '2019-02-23 21:34:56', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2019-02-23 21:34:56', '2019-02-23 21:34:56', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/ceramic-mugs.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2019-02-23 21:34:58', '2019-02-23 21:34:58', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2019-02-23 21:34:58', '2019-02-23 21:34:58', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/film-cameras.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2019-02-23 21:34:59', '2019-02-23 21:34:59', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt', '', '', '2019-02-23 21:34:59', '2019-02-23 21:34:59', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/flannel-shirt.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2019-02-23 21:35:01', '2019-02-23 21:35:01', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove', '', '', '2019-02-23 21:35:01', '2019-02-23 21:35:01', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/gas-stove.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2019-02-23 21:35:02', '2019-02-23 21:35:02', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque', '', '', '2019-02-23 21:35:02', '2019-02-23 21:35:02', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/hand-knit-toque.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2019-02-23 21:35:04', '2019-02-23 21:35:04', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots', '', '', '2019-02-23 21:35:04', '2019-02-23 21:35:04', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/hiking-boots.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2019-02-23 21:35:05', '2019-02-23 21:35:05', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos', '', '', '2019-02-23 21:35:05', '2019-02-23 21:35:05', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/large-thermos.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2019-02-23 21:35:07', '2019-02-23 21:35:07', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel', '', '', '2019-02-23 21:35:07', '2019-02-23 21:35:07', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/leather-satchel.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2019-02-23 21:35:08', '2019-02-23 21:35:08', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents', '', '', '2019-02-23 21:35:08', '2019-02-23 21:35:08', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/nylon-tents.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2019-02-23 21:35:10', '2019-02-23 21:35:10', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools', '', '', '2019-02-23 21:35:10', '2019-02-23 21:35:10', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/rustic-tools.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2019-02-23 21:35:12', '2019-02-23 21:35:12', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can', '', '', '2019-02-23 21:35:12', '2019-02-23 21:35:12', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/stew-can.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2019-02-23 21:35:13', '2019-02-23 21:35:13', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock', '', '', '2019-02-23 21:35:13', '2019-02-23 21:35:13', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/travel-hammock.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-02-23 21:35:15', '2019-02-23 21:35:15', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes', '', '', '2019-02-23 21:35:15', '2019-02-23 21:35:15', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/weathered-canoes.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2019-02-23 21:35:16', '2019-02-23 21:35:16', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax', '', '', '2019-02-23 21:35:16', '2019-02-23 21:35:16', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/wood-ax.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2019-02-24 05:42:53', '2019-02-24 05:42:53', '<!-- wp:heading {"level":4} -->\n<h4>Our Story</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4>Our Team</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-03-03 07:14:47', '2019-03-03 07:14:47', '', 0, 'http://localhost/stephanie/?page_id=43', 0, 'page', '', 0),
(44, 1, '2019-02-24 05:42:53', '2019-02-24 05:42:53', ' ', '', '', 'publish', 'closed', 'closed', '', '44', '', '', '2019-03-19 02:57:54', '2019-03-19 02:57:54', '', 0, 'http://localhost/stephanie/44/', 3, 'nav_menu_item', '', 0),
(45, 1, '2019-02-24 05:42:53', '2019-02-24 05:42:53', '<!-- wp:heading {"level":4} -->\n<h4>Our Story</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4>Our Team</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'about', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2019-02-24 05:42:53', '2019-02-24 05:42:53', '', 43, 'http://localhost/stephanie/43-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2019-02-25 05:15:18', '2019-02-25 05:15:18', '', 'Inhabitent Journal', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2019-02-25 05:15:18', '2019-02-25 05:15:18', '', 0, 'http://localhost/stephanie/?p=46', 0, 'post', '', 0),
(48, 1, '2019-02-25 04:57:41', '2019-02-25 04:57:41', '', 'home-hero', '', 'inherit', 'open', 'closed', '', 'home-hero', '', '', '2019-02-25 04:57:41', '2019-02-25 04:57:41', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/home-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2019-02-25 05:13:42', '2019-02-25 05:13:42', '', 'Shop Stuff', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2019-02-25 05:13:42', '2019-02-25 05:13:42', '', 9, 'http://localhost/stephanie/9-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2019-02-25 05:15:18', '2019-02-25 05:15:18', '', 'Inhabitent Journal', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2019-02-25 05:15:18', '2019-02-25 05:15:18', '', 46, 'http://localhost/stephanie/46-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-02-25 05:58:05', '2019-02-25 05:58:05', '<!-- wp:paragraph -->\n<p>Semiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Swag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tattooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial meditation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Intelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven\'t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.</p>\n<!-- /wp:paragraph -->', 'Getting Back to Nature in a canoe.', '', 'publish', 'closed', 'open', '', 'getting-back-to-nature-in-a-canoe', '', '', '2019-03-03 17:28:26', '2019-03-03 17:28:26', '', 0, 'http://localhost/stephanie/?p=52', 0, 'post', '', 0),
(53, 1, '2019-02-25 05:56:59', '2019-02-25 05:56:59', '<!-- wp:paragraph -->\n<p>Semiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Swag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tattooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial meditation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Intelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven\'t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.</p>\n<!-- /wp:paragraph -->', 'Getting Back to Nature in a canoe.', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2019-02-25 05:56:59', '2019-02-25 05:56:59', '', 52, 'http://localhost/stephanie/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2019-02-25 06:03:08', '2019-02-25 06:03:08', '<!-- wp:paragraph -->\n<p>Street art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Franzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde <g class="gr_ gr_7 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="7" data-gr-id="7">pabst</g> pour-over, semiotics poutine <g class="gr_ gr_8 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="8" data-gr-id="8">etsy</g> tousled chambray. Slow-carb <g class="gr_ gr_10 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace" id="10" data-gr-id="10">echo</g> park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Fixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut godard hammock you probably haven\'t heard of them. Swag meditation ramps crucifix chia messenger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache wayfarers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.</p>\n<!-- /wp:paragraph -->', 'A Night with Friends at the Beach', '', 'publish', 'open', 'open', '', 'a-night-with-friends-at-the-beach', '', '', '2019-02-25 06:09:35', '2019-02-25 06:09:35', '', 0, 'http://localhost/stephanie/?p=54', 0, 'post', '', 0),
(55, 1, '2019-02-25 06:02:21', '2019-02-25 06:02:21', '<!-- wp:paragraph -->\n<p>Street art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Franzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde pabst pour-over, semiotics poutine etsy tousled chambray. Slow-carb echo park jean shorts seitan. Salvia aesthetic gentrify man braid, mes</p>\n<!-- /wp:paragraph -->', 'A Night with Friends at the Beach', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2019-02-25 06:02:21', '2019-02-25 06:02:21', '', 54, 'http://localhost/stephanie/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2019-02-25 06:05:05', '2019-02-25 06:05:05', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-02-25 06:05:05', '2019-02-25 06:05:05', '', 1, 'http://localhost/stephanie/1-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2019-02-25 06:07:32', '2019-02-25 06:07:32', '<!-- wp:paragraph -->\n<p>Man braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Tacos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Banjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chillwave hashtag direct trade distillery pinterest +1 wolf selfies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Cardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affogato mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu readymade, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl biodiesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.</p>\n<!-- /wp:paragraph -->', 'Taking in the View at Big Mountain', '', 'publish', 'open', 'open', '', 'taking-in-the-view-at-big-mountain', '', '', '2019-02-25 06:07:32', '2019-02-25 06:07:32', '', 0, 'http://localhost/stephanie/?p=57', 0, 'post', '', 0),
(58, 1, '2019-02-25 06:07:27', '2019-02-25 06:07:27', '<!-- wp:paragraph -->\n<p>Man braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Tacos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Banjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chillwave hashtag direct trade distillery pinterest +1 wolf selfies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Cardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affogato mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu readymade, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl biodiesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.</p>\n<!-- /wp:paragraph -->', 'Taking in the View at Big Mountain', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2019-02-25 06:07:27', '2019-02-25 06:07:27', '', 57, 'http://localhost/stephanie/57-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2019-02-25 06:09:35', '2019-02-25 06:09:35', '<!-- wp:paragraph -->\n<p>Street art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Franzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde <g class="gr_ gr_7 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="7" data-gr-id="7">pabst</g> pour-over, semiotics poutine <g class="gr_ gr_8 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="8" data-gr-id="8">etsy</g> tousled chambray. Slow-carb <g class="gr_ gr_10 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace" id="10" data-gr-id="10">echo</g> park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Fixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut godard hammock you probably haven\'t heard of them. Swag meditation ramps crucifix chia messenger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache wayfarers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.</p>\n<!-- /wp:paragraph -->', 'A Night with Friends at the Beach', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2019-02-25 06:09:35', '2019-02-25 06:09:35', '', 54, 'http://localhost/stephanie/54-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2019-02-25 06:12:13', '2019-02-25 06:12:13', '<!-- wp:paragraph -->\n<p>Tote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters selvage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sartorial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You probably haven\'t heard of them ethical migas pour-over. You probably haven\'t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Stumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authentic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actually humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.</p>\n<!-- /wp:paragraph -->', 'Star-Gazing at the Night Sky', '', 'publish', 'open', 'open', '', 'star-gazing-at-the-night-sky', '', '', '2019-02-25 06:12:13', '2019-02-25 06:12:13', '', 0, 'http://localhost/stephanie/?p=61', 0, 'post', '', 0),
(62, 1, '2019-02-25 06:12:09', '2019-02-25 06:12:09', '<!-- wp:paragraph -->\n<p>Tote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters selvage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sartorial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You probably haven\'t heard of them ethical migas pour-over. You probably haven\'t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Stumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authentic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actually humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.</p>\n<!-- /wp:paragraph -->', 'Star-Gazing at the Night Sky', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2019-02-25 06:12:09', '2019-02-25 06:12:09', '', 61, 'http://localhost/stephanie/61-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2019-02-25 06:38:42', '2019-02-25 06:38:42', '', 'Archive', '', 'publish', 'closed', 'closed', '', 'archive', '', '', '2019-02-25 06:38:42', '2019-02-25 06:38:42', '', 0, 'http://localhost/stephanie/?page_id=64', 0, 'page', '', 0),
(66, 1, '2019-02-25 06:38:42', '2019-02-25 06:38:42', '', 'Archive', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-02-25 06:38:42', '2019-02-25 06:38:42', '', 64, 'http://localhost/stephanie/64-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2019-02-25 06:39:24', '2019-02-25 06:39:24', '', 'Archive', '', 'inherit', 'closed', 'closed', '', '64-autosave-v1', '', '', '2019-02-25 06:39:24', '2019-02-25 06:39:24', '', 64, 'http://localhost/stephanie/64-autosave-v1/', 0, 'revision', '', 0),
(70, 1, '2019-02-26 03:17:40', '2019-02-26 03:17:40', '<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Beach Tent', '', 'trash', 'open', 'open', '', 'beach-tent__trashed', '', '', '2019-02-26 03:25:07', '2019-02-26 03:25:07', '', 0, 'http://localhost/stephanie/?p=70', 0, 'post', '', 0),
(71, 1, '2019-02-26 03:15:46', '2019-02-26 03:15:46', '<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Beach Tent', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2019-02-26 03:15:46', '2019-02-26 03:15:46', '', 70, 'http://localhost/stephanie/70-revision-v1/', 0, 'revision', '', 0),
(73, 0, '2019-02-26 03:25:01', '2019-02-26 03:25:01', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p> Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'Beach Tent', '', 'publish', 'closed', 'closed', '', 'beach-tent', '', '', '2019-03-04 04:23:32', '2019-03-04 04:23:32', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=73', 0, 'product', '', 0),
(76, 0, '2019-02-26 03:27:29', '2019-02-26 03:27:29', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">kogi</g>. Forage four <g class="gr_ gr_15 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="15" data-gr-id="15">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="13" data-gr-id="13">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Camper Van', '', 'publish', 'closed', 'closed', '', 'camper-van', '', '', '2019-03-04 04:22:59', '2019-03-04 04:22:59', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=76', 0, 'product', '', 0),
(77, 0, '2019-02-26 03:32:10', '2019-02-26 03:32:10', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">kogi</g>. Forage four <g class="gr_ gr_15 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="15" data-gr-id="15">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="13" data-gr-id="13">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Ceramic Mug', '', 'publish', 'closed', 'closed', '', 'ceramic-mug', '', '', '2019-03-04 04:15:59', '2019-03-04 04:15:59', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=77', 0, 'product', '', 0),
(78, 0, '2019-02-26 03:38:08', '2019-02-26 03:38:08', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">kogi</g>. Forage four <g class="gr_ gr_15 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="15" data-gr-id="15">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="13" data-gr-id="13">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Film Camera', '', 'publish', 'closed', 'closed', '', 'film-camera', '', '', '2019-03-04 04:14:54', '2019-03-04 04:14:54', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=78', 0, 'product', '', 0),
(79, 0, '2019-02-26 03:41:21', '2019-02-26 03:41:21', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_42 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="42" data-gr-id="42">kogi</g>. Forage four <g class="gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="12" data-gr-id="12">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Flannel Shirt', '', 'publish', 'closed', 'closed', '', 'flannel-shirt-2', '', '', '2019-03-11 01:04:30', '2019-03-11 01:04:30', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=79', 0, 'product', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(80, 0, '2019-02-26 03:44:00', '2019-02-26 03:44:00', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.\n</p>\n<!-- /wp:paragraph -->', 'Gas Stove', '', 'publish', 'closed', 'closed', '', 'gas-stove', '', '', '2019-03-04 04:28:15', '2019-03-04 04:28:15', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=80', 0, 'product', '', 0),
(81, 0, '2019-02-26 03:51:59', '2019-02-26 03:51:59', '<!-- wp:html -->\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.\n<!-- /wp:html -->', 'Hand-Knit Toque', '', 'publish', 'closed', 'closed', '', 'hand-knit-toque', '', '', '2019-03-04 04:27:47', '2019-03-04 04:27:47', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=81', 0, 'product', '', 0),
(83, 0, '2019-02-26 03:54:33', '2019-02-26 03:54:33', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>&lt;p&gt;Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.&lt;/p&gt;</p>\n<!-- /wp:paragraph -->', 'Hiking Boots', '', 'publish', 'closed', 'closed', '', 'hiking-boots', '', '', '2019-03-04 04:25:46', '2019-03-04 04:25:46', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=83', 0, 'product', '', 0),
(84, 0, '2019-02-26 03:56:42', '2019-02-26 03:56:42', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">kogi</g>. Forage four <g class="gr_ gr_15 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="15" data-gr-id="15">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="13" data-gr-id="13">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Large Thermos', '', 'publish', 'closed', 'closed', '', 'large-thermos', '', '', '2019-03-04 04:21:56', '2019-03-04 04:21:56', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=84', 0, 'product', '', 0),
(85, 0, '2019-02-26 03:58:09', '2019-02-26 03:58:09', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Leather Satchel', '', 'publish', 'closed', 'closed', '', 'leather-satchel', '', '', '2019-03-04 04:25:17', '2019-03-04 04:25:17', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=85', 0, 'product', '', 0),
(86, 0, '2019-02-26 03:59:40', '2019-02-26 03:59:40', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Nylon Tents', '', 'publish', 'closed', 'closed', '', 'nylon-tents', '', '', '2019-03-04 04:24:40', '2019-03-04 04:24:40', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=86', 0, 'product', '', 0),
(87, 0, '2019-02-26 04:00:47', '2019-02-26 04:00:47', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Rustic Tools', '', 'publish', 'closed', 'closed', '', 'rustic-tools', '', '', '2019-03-04 04:14:25', '2019-03-04 04:14:25', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=87', 0, 'product', '', 0),
(88, 0, '2019-02-26 04:02:23', '2019-02-26 04:02:23', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui <g class="gr_ gr_9 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="9" data-gr-id="9">kogi</g>. Forage four <g class="gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="12" data-gr-id="12">loko</g> iPhone, raw denim pop-up taxidermy <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="10" data-gr-id="10">etsy</g> gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="11" data-gr-id="11">brooklyn</g> retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Stew Can', '', 'publish', 'closed', 'closed', '', 'stew-can-2', '', '', '2019-03-11 01:04:23', '2019-03-11 01:04:23', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=88', 0, 'product', '', 0),
(89, 0, '2019-02-26 04:03:50', '2019-02-26 04:03:50', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Travel Hammock', '', 'publish', 'closed', 'closed', '', 'travel-hammock-2', '', '', '2019-03-11 01:04:15', '2019-03-11 01:04:15', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=89', 0, 'product', '', 0),
(90, 0, '2019-02-26 04:05:04', '2019-02-26 04:05:04', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Weathered Canoes', '', 'publish', 'closed', 'closed', '', 'weathered-canoes', '', '', '2019-03-04 04:13:44', '2019-03-04 04:13:44', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=90', 0, 'product', '', 0),
(91, 0, '2019-02-26 04:06:07', '2019-02-26 04:06:07', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Wood Axe', '', 'publish', 'closed', 'closed', '', 'wood-axe', '', '', '2019-03-11 02:24:06', '2019-03-11 02:24:06', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=91', 0, 'product', '', 0),
(93, 1, '2019-02-26 04:39:27', '2019-02-26 04:39:27', '<!-- wp:paragraph -->\n<p>Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</p>\n<!-- /wp:paragraph -->', 'Van Camping Photo Contest', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2019-02-26 04:39:27', '2019-02-26 04:39:27', '', 0, 'http://localhost/stephanie/?p=93', 0, 'post', '', 0),
(94, 1, '2019-02-26 04:38:47', '2019-02-26 04:38:47', '<!-- wp:paragraph -->\n<p>Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</p>\n<!-- /wp:paragraph -->', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2019-02-26 04:38:47', '2019-02-26 04:38:47', '', 93, 'http://localhost/stephanie/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2019-02-26 04:42:46', '2019-02-26 04:42:46', '<!-- wp:paragraph -->\n<p>Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland&nbsp;</p>\n<!-- /wp:paragraph -->', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2019-02-26 04:42:46', '2019-02-26 04:42:46', '', 0, 'http://localhost/stephanie/?p=95', 0, 'post', '', 0),
(96, 1, '2019-02-26 04:42:42', '2019-02-26 04:42:42', '<!-- wp:paragraph -->\n<p>Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland&nbsp;</p>\n<!-- /wp:paragraph -->', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2019-02-26 04:42:42', '2019-02-26 04:42:42', '', 95, 'http://localhost/stephanie/95-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2019-02-26 04:45:08', '2019-02-26 04:45:08', '<!-- wp:paragraph -->\n<p>Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'How To: Eating Healthy Meals in the Wild', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2019-02-26 04:45:08', '2019-02-26 04:45:08', '', 0, 'http://localhost/stephanie/?p=97', 0, 'post', '', 0),
(98, 1, '2019-02-26 04:45:00', '2019-02-26 04:45:00', '<!-- wp:paragraph -->\n<p>Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2019-02-26 04:45:00', '2019-02-26 04:45:00', '', 97, 'http://localhost/stephanie/97-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2019-02-26 04:56:50', '2019-02-26 04:56:50', '<!-- wp:paragraph -->\n<p>Wayfarers VHS chambray <g class="gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep" id="7" data-gr-id="7"><g class="gr_ gr_5 gr-alert gr_spell gr_inline_cards gr_disable_anim_appear ContextualSpelling ins-del multiReplace" id="5" data-gr-id="5">schlitz</g>,</g> ramps semiotics post-ironic <g class="gr_ gr_6 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="6" data-gr-id="6">franzen</g> fixie wolf polaroid viral. <g class="gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del" id="4" data-gr-id="4">Blue bottle</g> scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</p>\n<!-- /wp:paragraph -->', '5 Tips for Solo Camping', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2019-02-26 04:56:50', '2019-02-26 04:56:50', '', 0, 'http://localhost/stephanie/?p=99', 0, 'post', '', 0),
(100, 1, '2019-02-26 04:56:47', '2019-02-26 04:56:47', '<!-- wp:paragraph -->\n<p>Wayfarers VHS chambray <g class="gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep" id="7" data-gr-id="7"><g class="gr_ gr_5 gr-alert gr_spell gr_inline_cards gr_disable_anim_appear ContextualSpelling ins-del multiReplace" id="5" data-gr-id="5">schlitz</g>,</g> ramps semiotics post-ironic <g class="gr_ gr_6 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="6" data-gr-id="6">franzen</g> fixie wolf polaroid viral. <g class="gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del" id="4" data-gr-id="4">Blue bottle</g> scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</p>\n<!-- /wp:paragraph -->', '5 Tips for Solo Camping', '', 'inherit', 'closed', 'closed', '', '99-revision-v1', '', '', '2019-02-26 04:56:47', '2019-02-26 04:56:47', '', 99, 'http://localhost/stephanie/99-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2019-02-26 04:59:06', '2019-02-26 04:59:06', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos <g class="gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="4" data-gr-id="4">helvetica</g> semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>pop-up. Slow-carb bespoke biodiesel sartorial <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="10" data-gr-id="10">migas</g> fashion <g class="gr_ gr_14 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace" id="14" data-gr-id="14">axe</g>, mumblecore pop-up <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="11" data-gr-id="11">tumblr</g>. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos <g class="gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="12" data-gr-id="12">microdosing</g> poutine, kombucha YOLO mumblecore. Freegan typewriter distillery <g class="gr_ gr_8 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="8" data-gr-id="8">truffaut</g>. Portland slow-carb hammock, <g class="gr_ gr_9 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="9" data-gr-id="9">yuccie</g> cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="13" data-gr-id="13">tumblr</g>. </p>\n<!-- /wp:paragraph -->', 'Glamping Made Easy', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2019-02-26 05:01:07', '2019-02-26 05:01:07', '', 0, 'http://localhost/stephanie/?p=101', 0, 'post', '', 0),
(102, 1, '2019-02-26 04:58:56', '2019-02-26 04:58:56', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch</p>\n<!-- /wp:paragraph -->', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '101-revision-v1', '', '', '2019-02-26 04:58:56', '2019-02-26 04:58:56', '', 101, 'http://localhost/stephanie/101-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2019-02-26 04:59:43', '2019-02-26 04:59:43', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos <g class="gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="4" data-gr-id="4">helvetica</g> semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.</p>\n<!-- /wp:paragraph -->', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '101-revision-v1', '', '', '2019-02-26 04:59:43', '2019-02-26 04:59:43', '', 101, 'http://localhost/stephanie/101-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2019-02-26 05:01:07', '2019-02-26 05:01:07', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos <g class="gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="4" data-gr-id="4">helvetica</g> semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>pop-up. Slow-carb bespoke biodiesel sartorial <g class="gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="10" data-gr-id="10">migas</g> fashion <g class="gr_ gr_14 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace" id="14" data-gr-id="14">axe</g>, mumblecore pop-up <g class="gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="11" data-gr-id="11">tumblr</g>. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos <g class="gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="12" data-gr-id="12">microdosing</g> poutine, kombucha YOLO mumblecore. Freegan typewriter distillery <g class="gr_ gr_8 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="8" data-gr-id="8">truffaut</g>. Portland slow-carb hammock, <g class="gr_ gr_9 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="9" data-gr-id="9">yuccie</g> cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO <g class="gr_ gr_13 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling" id="13" data-gr-id="13">tumblr</g>. </p>\n<!-- /wp:paragraph -->', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '101-revision-v1', '', '', '2019-02-26 05:01:07', '2019-02-26 05:01:07', '', 101, 'http://localhost/stephanie/101-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2019-02-26 05:24:28', '2019-02-26 05:24:28', '<!-- wp:paragraph -->\n<p>Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '97-autosave-v1', '', '', '2019-02-26 05:24:28', '2019-02-26 05:24:28', '', 97, 'http://localhost/stephanie/97-autosave-v1/', 0, 'revision', '', 0),
(106, 1, '2019-02-26 05:26:26', '2019-02-26 05:26:26', ' ', '', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2019-03-19 02:57:54', '2019-03-19 02:57:54', '', 0, 'http://localhost/stephanie/?p=106', 1, 'nav_menu_item', '', 0),
(107, 1, '2019-02-26 05:26:42', '2019-02-26 05:26:42', '<!-- wp:heading {"level":4} -->\n<h4>Our Story</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4>Our Team</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2019-02-26 05:26:42', '2019-02-26 05:26:42', '', 43, 'http://localhost/stephanie/43-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2019-02-26 05:27:15', '2019-02-26 05:27:15', '', 'Journal', '', 'publish', 'closed', 'closed', '', 'journal', '', '', '2019-03-03 17:36:21', '2019-03-03 17:36:21', '', 0, 'http://localhost/stephanie/?page_id=108', 0, 'page', '', 0),
(109, 1, '2019-02-26 05:27:15', '2019-02-26 05:27:15', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2019-03-19 02:57:54', '2019-03-19 02:57:54', '', 0, 'http://localhost/stephanie/109/', 2, 'nav_menu_item', '', 0),
(110, 1, '2019-02-26 05:27:15', '2019-02-26 05:27:15', '', 'Journal', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2019-02-26 05:27:15', '2019-02-26 05:27:15', '', 108, 'http://localhost/stephanie/108-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2019-02-26 05:27:46', '2019-02-26 05:27:46', '', 'Find Us', '', 'publish', 'closed', 'closed', '', 'find-us', '', '', '2019-03-04 16:35:56', '2019-03-04 16:35:56', '', 0, 'http://localhost/stephanie/?page_id=111', 0, 'page', '', 0),
(112, 1, '2019-02-26 05:27:46', '2019-02-26 05:27:46', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2019-03-19 02:57:54', '2019-03-19 02:57:54', '', 0, 'http://localhost/stephanie/112/', 4, 'nav_menu_item', '', 0),
(113, 1, '2019-02-26 05:27:46', '2019-02-26 05:27:46', '', 'Find Us', '', 'inherit', 'closed', 'closed', '', '111-revision-v1', '', '', '2019-02-26 05:27:46', '2019-02-26 05:27:46', '', 111, 'http://localhost/stephanie/111-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2019-02-26 05:28:21', '2019-02-26 05:28:21', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2019-02-26 05:28:21', '2019-02-26 05:28:21', '', 9, 'http://localhost/stephanie/9-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2019-02-26 05:32:01', '2019-02-26 05:32:01', 'http://localhost/stephanie/wp-content/uploads/2019/02/cropped-canoe-girl.jpg', 'cropped-canoe-girl.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-canoe-girl-jpg', '', '', '2019-02-26 05:32:01', '2019-02-26 05:32:01', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/cropped-canoe-girl.jpg', 0, 'attachment', 'image/jpeg', 0),
(117, 1, '2019-02-26 05:33:06', '2019-02-26 05:33:06', '{"blogname":{"value":"Inhabitent","type":"option","user_id":1,"date_modified_gmt":"2019-02-26 05:32:16"},"blogdescription":{"value":"","type":"option","user_id":1,"date_modified_gmt":"2019-02-26 05:32:16"},"site_icon":{"value":116,"type":"option","user_id":1,"date_modified_gmt":"2019-02-26 05:32:16"},"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2019-02-26 05:33:06"},"page_for_posts":{"value":"108","type":"option","user_id":1,"date_modified_gmt":"2019-02-26 05:33:06"}}', '', '', 'trash', 'closed', 'closed', '', '2a3944eb-76b7-4f70-9d7d-915cf7c54661', '', '', '2019-02-26 05:33:06', '2019-02-26 05:33:06', '', 0, 'http://localhost/stephanie/?p=117', 0, 'customize_changeset', '', 0),
(118, 0, '2019-02-26 15:03:29', '2019-02-26 15:03:29', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.               Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'trash', 'closed', 'closed', '', '__trashed-2', '', '', '2019-02-26 15:03:29', '2019-02-26 15:03:29', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=118', 0, 'product', '', 0),
(120, 1, '2019-02-26 15:06:03', '2019-02-26 15:06:03', '<!-- wp:paragraph -->\n<p>Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild-2', '', '', '2019-02-26 15:06:03', '2019-02-26 15:06:03', '', 0, 'http://localhost/stephanie/?p=120', 0, 'post', '', 0),
(121, 1, '2019-02-26 15:05:59', '2019-02-26 15:05:59', '<!-- wp:paragraph -->\n<p>Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2019-02-26 15:05:59', '2019-02-26 15:05:59', '', 120, 'http://localhost/stephanie/120-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(123, 1, '2019-02-26 15:13:55', '2019-02-26 15:13:55', '', 'dark-wood', '', 'inherit', 'open', 'closed', '', 'dark-wood', '', '', '2019-02-26 15:13:55', '2019-02-26 15:13:55', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/dark-wood.png', 0, 'attachment', 'image/png', 0),
(128, 1, '2019-02-26 19:18:04', '2019-02-26 19:18:04', '', 'home-hero', '', 'inherit', 'open', 'closed', '', 'home-hero-2', '', '', '2019-02-26 19:18:04', '2019-02-26 19:18:04', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/home-hero-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(129, 1, '2019-02-26 20:28:03', '2019-02-26 20:28:03', '', 'home-hero', '', 'inherit', 'open', 'closed', '', 'home-hero-3', '', '', '2019-02-26 20:28:03', '2019-02-26 20:28:03', '', 0, 'http://localhost/stephanie/wp-content/uploads/2019/02/home-hero-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2019-03-03 06:18:11', '2019-03-03 06:18:11', '{"nav_menu_item[11]":{"value":{"menu_item_parent":0,"object_id":11,"object":"custom","type":"custom","type_label":"Custom Link","title":"<h1 class=\\"site-title\\">Inhabitent<\\/h1>","url":"http:\\/\\/localhost\\/stephanie\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","nav_menu_term_id":2,"position":1,"status":"publish","original_title":"","_invalid":false},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2019-03-03 06:15:21"},"nav_menu_item[-7260202980371175000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":6,"type":"custom","title":"<i class=\\"fa fa-search\\"><\\/i>","url":"http:\\/\\/localhost\\/stephanie\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"<i class=\\"fa fa-search\\"><\\/i>","nav_menu_term_id":2,"_invalid":false,"type_label":"Custom Link"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2019-03-03 06:17:21"},"custom_css[redstarter-master]":{"value":".menu-toggle{display:none;}","type":"custom_css","user_id":1,"date_modified_gmt":"2019-03-03 06:18:11"}}', '', '', 'trash', 'closed', 'closed', '', '8b3b3072-f8c3-406d-a7cc-321aa098b9f6', '', '', '2019-03-03 06:18:11', '2019-03-03 06:18:11', '', 0, 'http://localhost/stephanie/?p=132', 0, 'customize_changeset', '', 0),
(134, 1, '2019-03-03 06:18:11', '2019-03-03 06:18:11', '.menu-toggle{display:none;}', 'redstarter-master', '', 'publish', 'closed', 'closed', '', 'redstarter-master', '', '', '2019-03-03 06:18:11', '2019-03-03 06:18:11', '', 0, 'http://localhost/stephanie/redstarter-master/', 0, 'custom_css', '', 0),
(135, 1, '2019-03-03 06:18:11', '2019-03-03 06:18:11', '.menu-toggle{display:none;}', 'redstarter-master', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2019-03-03 06:18:11', '2019-03-03 06:18:11', '', 134, 'http://localhost/stephanie/134-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2019-03-03 06:42:00', '2019-03-03 06:42:00', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/stephanie/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-03-03 06:42:00', '2019-03-03 06:42:00', '', 2, 'http://localhost/stephanie/2-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2019-03-03 06:49:57', '2019-03-03 06:49:57', '{"page_for_posts":{"value":"0","type":"option","user_id":1,"date_modified_gmt":"2019-03-03 06:49:57"}}', '', '', 'trash', 'closed', 'closed', '', 'da22cb79-2f27-4f3e-b641-3be04f99f8ea', '', '', '2019-03-03 06:49:57', '2019-03-03 06:49:57', '', 0, 'http://localhost/stephanie/da22cb79-2f27-4f3e-b641-3be04f99f8ea/', 0, 'customize_changeset', '', 0),
(138, 1, '2019-03-03 06:52:53', '2019-03-03 06:52:53', '', 'Front Page', '', 'publish', 'closed', 'closed', '', 'front-page', '', '', '2019-03-03 06:52:53', '2019-03-03 06:52:53', '', 0, 'http://localhost/stephanie/?page_id=138', 0, 'page', '', 0),
(140, 1, '2019-03-03 06:52:53', '2019-03-03 06:52:53', '', 'Front Page', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2019-03-03 06:52:53', '2019-03-03 06:52:53', '', 138, 'http://localhost/stephanie/138-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2019-03-03 06:54:11', '2019-03-03 06:54:11', '{"page_on_front":{"value":"138","type":"option","user_id":1,"date_modified_gmt":"2019-03-03 06:54:11"}}', '', '', 'trash', 'closed', 'closed', '', 'f1d35098-ebd0-4cfd-9d5c-fd3dccedd1f7', '', '', '2019-03-03 06:54:11', '2019-03-03 06:54:11', '', 0, 'http://localhost/stephanie/f1d35098-ebd0-4cfd-9d5c-fd3dccedd1f7/', 0, 'customize_changeset', '', 0),
(144, 1, '2019-03-03 07:44:17', '2019-03-03 07:44:17', '{"sidebars_widgets[sidebar-1]":{"value":["custom_html-3","bsuiness-hours-3","archives-3"],"type":"option","user_id":1,"date_modified_gmt":"2019-03-03 07:44:17"},"widget_custom_html[3]":{"value":{"encoded_serialized_instance":"YToyOntzOjU6InRpdGxlIjtzOjEyOiJDb250YWN0IEluZm8iO3M6NzoiY29udGVudCI7czozOTE6IjxwPjxpIGNsYXNzPSJmYSBmYS1lbnZlbG9wZSI+PC9pPjxhIGhyZWY9Im1haWx0bzppbmZvQGluaGFiaXRlbnQuY29tIj5pbmZvQGluaGFiaXRlbnQuY29tPC9hPjwvcD4NCgkJCQkJCQk8cD48aSBjbGFzcz0iZmEgZmEtcGhvbmUiPjwvaT48YSBocmVmPSJ0ZWw6NTU1MzQzNDU2Nzg5MSI+Nzc4LTQ1Ni03ODkxPC9hPjwvcD4NCgkJCQkJCQk8cD4NCgkJCQkJCQkJPHNwYW4+PGkgY2xhc3M9ImZhIGZhLWZhY2Vib29rLXNxdWFyZSI+PC9pPjwvc3Bhbj4NCgkJCQkJCQkJPHNwYW4+PGkgY2xhc3M9ImZhIGZhLXR3aXR0ZXItc3F1YXJlIj48L2k+PC9zcGFuPg0KCQkJCQkJCQk8c3Bhbj48aSBjbGFzcz0iZmEgZmEtZ29vZ2xlLXBsdXMtc3F1YXJlIj48L2k+PC9zcGFuPg0KCQkJCQkJCTwvcD4iO30=","title":"Contact Info","is_widget_customizer_js_value":true,"instance_hash_key":"ff95393b8b315041005ef66465ff4618"},"type":"option","user_id":1,"date_modified_gmt":"2019-03-03 07:43:44"},"widget_bsuiness-hours[3]":{"value":{"encoded_serialized_instance":"YTo0OntzOjU6InRpdGxlIjtzOjE0OiJCdXNpbmVzcyBIb3VycyI7czoxMzoibW9uZGF5X2ZyaWRheSI7czoyOiI1NyI7czo4OiJzYXR1cmRheSI7czoxNDoiQnVzaW5lc3MgSG91cnMiO3M6Njoic3VuZGF5IjtzOjE0OiJCdXNpbmVzcyBIb3VycyI7fQ==","title":"Business Hours","is_widget_customizer_js_value":true,"instance_hash_key":"2b43000b73528a8c5e4bc5a0a36fd246"},"type":"option","user_id":1,"date_modified_gmt":"2019-03-03 07:44:17"},"widget_archives[3]":{"value":[],"type":"option","user_id":1,"date_modified_gmt":"2019-03-03 07:44:17"}}', '', '', 'trash', 'closed', 'closed', '', '7db3b6d5-751c-49ed-8b58-89714c3afb1d', '', '', '2019-03-03 07:44:17', '2019-03-03 07:44:17', '', 0, 'http://localhost/stephanie/?p=144', 0, 'customize_changeset', '', 0),
(146, 1, '2019-03-03 16:23:28', '2019-03-03 16:23:28', '', 'Product Type', '', 'publish', 'closed', 'closed', '', 'product-type', '', '', '2019-03-03 16:23:28', '2019-03-03 16:23:28', '', 0, 'http://localhost/stephanie/?page_id=146', 0, 'page', '', 0),
(147, 1, '2019-03-03 16:23:28', '2019-03-03 16:23:28', '', 'Product Type', '', 'inherit', 'closed', 'closed', '', '146-revision-v1', '', '', '2019-03-03 16:23:28', '2019-03-03 16:23:28', '', 146, 'http://localhost/stephanie/146-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2019-03-04 03:32:45', '2019-03-04 03:32:45', '', 'DO', '', 'publish', 'closed', 'closed', '', 'do', '', '', '2019-03-04 03:36:26', '2019-03-04 03:36:26', '', 0, 'http://localhost/stephanie/?page_id=150', 0, 'page', '', 0),
(151, 1, '2019-03-04 03:32:45', '2019-03-04 03:32:45', '', 'Do', '', 'inherit', 'closed', 'closed', '', '150-revision-v1', '', '', '2019-03-04 03:32:45', '2019-03-04 03:32:45', '', 150, 'http://localhost/stephanie/150-revision-v1/', 0, 'revision', '', 0),
(153, 1, '2019-03-04 03:35:17', '2019-03-04 03:35:17', '', 'EAT', '', 'publish', 'closed', 'closed', '', 'eat', '', '', '2019-03-04 03:35:17', '2019-03-04 03:35:17', '', 0, 'http://localhost/stephanie/?page_id=153', 0, 'page', '', 0),
(154, 1, '2019-03-04 03:35:17', '2019-03-04 03:35:17', '', 'EAT', '', 'inherit', 'closed', 'closed', '', '153-revision-v1', '', '', '2019-03-04 03:35:17', '2019-03-04 03:35:17', '', 153, 'http://localhost/stephanie/153-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2019-03-04 03:36:26', '2019-03-04 03:36:26', '', 'DO', '', 'inherit', 'closed', 'closed', '', '150-revision-v1', '', '', '2019-03-04 03:36:26', '2019-03-04 03:36:26', '', 150, 'http://localhost/stephanie/150-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2019-03-04 03:37:43', '2019-03-04 03:37:43', '', 'SLEEP', '', 'publish', 'closed', 'closed', '', 'sleep', '', '', '2019-03-04 03:37:43', '2019-03-04 03:37:43', '', 0, 'http://localhost/stephanie/?page_id=158', 0, 'page', '', 0),
(159, 1, '2019-03-04 03:37:43', '2019-03-04 03:37:43', '', 'SLEEP', '', 'inherit', 'closed', 'closed', '', '158-revision-v1', '', '', '2019-03-04 03:37:43', '2019-03-04 03:37:43', '', 158, 'http://localhost/stephanie/158-revision-v1/', 0, 'revision', '', 0),
(161, 1, '2019-03-04 03:38:17', '2019-03-04 03:38:17', '', 'WEAR', '', 'publish', 'closed', 'closed', '', 'wear', '', '', '2019-03-04 03:38:17', '2019-03-04 03:38:17', '', 0, 'http://localhost/stephanie/?page_id=161', 0, 'page', '', 0),
(162, 1, '2019-03-04 03:38:17', '2019-03-04 03:38:17', '', 'WEAR', '', 'inherit', 'closed', 'closed', '', '161-revision-v1', '', '', '2019-03-04 03:38:17', '2019-03-04 03:38:17', '', 161, 'http://localhost/stephanie/161-revision-v1/', 0, 'revision', '', 0),
(163, 1, '2019-03-04 03:57:01', '2019-03-04 03:57:01', '<!-- wp:paragraph -->\n<p>Man braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Tacos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Banjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chillwave hashtag direct trade distillery pinterest +1 wolf selfies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Cardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affogato mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu readymade, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl biodiesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.</p>\n<!-- /wp:paragraph -->', 'Taking in the View at Big Mountain', '', 'inherit', 'closed', 'closed', '', '57-autosave-v1', '', '', '2019-03-04 03:57:01', '2019-03-04 03:57:01', '', 57, 'http://localhost/stephanie/57-autosave-v1/', 0, 'revision', '', 0),
(166, 1, '2019-03-10 06:21:26', '2019-03-10 06:21:26', '<!-- wp:paragraph -->\n<p>Product Type: Where</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Price: $45.00</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Flannel Shirt', '', 'trash', 'open', 'open', '', 'flannel-shirt__trashed', '', '', '2019-03-11 03:04:18', '2019-03-11 03:04:18', '', 0, 'http://localhost/stephanie/?p=166', 0, 'post', '', 0),
(167, 1, '2019-03-10 06:21:26', '2019-03-10 06:21:26', '<!-- wp:paragraph -->\n<p>Product Type: Where</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Price: $45.00</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Flannel Shirt', '', 'inherit', 'closed', 'closed', '', '166-revision-v1', '', '', '2019-03-10 06:21:26', '2019-03-10 06:21:26', '', 166, 'http://localhost/stephanie/166-revision-v1/', 0, 'revision', '', 0),
(168, 1, '2019-03-10 06:23:30', '2019-03-10 06:23:30', '<!-- wp:paragraph -->\n<p>Product Type: Sleep</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Price: $75.00</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Travel Hammock', '', 'trash', 'open', 'open', '', 'travel-hammock__trashed', '', '', '2019-03-11 01:01:08', '2019-03-11 01:01:08', '', 0, 'http://localhost/stephanie/?p=168', 0, 'post', '', 0),
(169, 1, '2019-03-10 06:23:30', '2019-03-10 06:23:30', '<!-- wp:paragraph -->\n<p>Product Type: Sleep</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Price: $75.00</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:paragraph -->', 'Travel Hammock', '', 'inherit', 'closed', 'closed', '', '168-revision-v1', '', '', '2019-03-10 06:23:30', '2019-03-10 06:23:30', '', 168, 'http://localhost/stephanie/168-revision-v1/', 0, 'revision', '', 0),
(170, 1, '2019-03-10 06:24:37', '2019-03-10 06:24:37', '', 'Stew Can', '', 'trash', 'open', 'open', '', 'stew-can__trashed', '', '', '2019-03-11 03:04:13', '2019-03-11 03:04:13', '', 0, 'http://localhost/stephanie/?p=170', 0, 'post', '', 0),
(171, 1, '2019-03-10 06:24:37', '2019-03-10 06:24:37', '', 'Stew Can', '', 'inherit', 'closed', 'closed', '', '170-revision-v1', '', '', '2019-03-10 06:24:37', '2019-03-10 06:24:37', '', 170, 'http://localhost/stephanie/170-revision-v1/', 0, 'revision', '', 0),
(174, 0, '2019-03-11 00:41:29', '2019-03-11 00:41:29', '<!-- wp:html -->\n<p\n style="text-align:center">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>\n<!-- /wp:html -->', 'Stew Can', '', 'trash', 'closed', 'closed', '', 'stew-can__trashed', '', '', '2019-03-11 02:24:12', '2019-03-11 02:24:12', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=174', 0, 'product', '', 0),
(180, 0, '2019-03-11 00:58:56', '2019-03-11 00:58:56', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.\n</p>\n<!-- /wp:paragraph -->', 'Travel Hammock', '', 'trash', 'closed', 'closed', '', 'travel-hammock__trashed', '', '', '2019-03-11 02:23:52', '2019-03-11 02:23:52', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=180', 0, 'product', '', 0),
(182, 0, '2019-03-11 01:00:35', '2019-03-11 01:00:35', '<!-- wp:paragraph {"placeholder":"Add the product description here."} -->\n<p> \nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'Flannel Shirt', '', 'trash', 'closed', 'closed', '', 'flannel-shirt__trashed', '', '', '2019-03-11 02:23:44', '2019-03-11 02:23:44', '', 0, 'http://localhost/stephanie/?post_type=product&#038;p=182', 0, 'product', '', 0),
(183, 1, '2019-03-19 01:18:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-03-19 01:18:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/stephanie/?p=183', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(44, 2, 0),
(46, 1, 0),
(52, 3, 0),
(54, 3, 0),
(57, 3, 0),
(61, 3, 0),
(70, 4, 0),
(73, 20, 0),
(76, 20, 0),
(77, 19, 0),
(78, 18, 0),
(79, 21, 0),
(80, 19, 0),
(81, 21, 0),
(83, 21, 0),
(84, 19, 0),
(85, 21, 0),
(86, 20, 0),
(87, 18, 0),
(88, 19, 0),
(89, 20, 0),
(90, 18, 0),
(91, 18, 0),
(93, 1, 0),
(93, 6, 0),
(93, 7, 0),
(95, 1, 0),
(95, 8, 0),
(95, 9, 0),
(97, 1, 0),
(97, 10, 0),
(97, 11, 0),
(99, 1, 0),
(101, 1, 0),
(106, 2, 0),
(109, 2, 0),
(112, 2, 0),
(120, 1, 0),
(166, 16, 0),
(168, 15, 0),
(170, 14, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 6),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'category', '', 0, 4),
(4, 4, 'category', '', 0, 0),
(5, 5, 'post_tag', '', 0, 0),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'post_tag', '', 0, 1),
(11, 11, 'post_tag', '', 0, 1),
(12, 12, 'category', '', 0, 0),
(13, 13, 'category', '', 0, 0),
(14, 14, 'category', '', 0, 0),
(15, 15, 'category', '', 0, 0),
(16, 16, 'category', '', 0, 0),
(18, 18, 'new_product_type', '', 0, 4),
(19, 19, 'new_product_type', '', 0, 4),
(20, 20, 'new_product_type', '', 0, 4),
(21, 21, 'new_product_type', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Inhabitent Journal', 'journal', 0),
(2, 'myMain', 'mymain', 0),
(3, 'Adventures', 'adventures', 0),
(4, 'Products', 'products', 0),
(5, 'Price', 'price', 0),
(6, 'Photography', 'photography', 0),
(7, 'Vans', 'vans', 0),
(8, 'Campfires', 'campfires', 0),
(9, 'Drinks', 'drinks', 0),
(10, 'Food', 'food', 0),
(11, 'Healthy', 'healthy', 0),
(12, 'Contact Info', 'contact', 0),
(13, 'Do', 'do', 0),
(14, 'Eat', 'eat', 0),
(15, 'Sleep', 'sleep', 0),
(16, 'Wear', 'wear', 0),
(18, 'DO', 'do', 0),
(19, 'EAT', 'eat', 0),
(20, 'SLEEP', 'sleep', 0),
(21, 'WEAR', 'wear', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'SparkleWolf17'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"33ec079c5388a65a5dcc9eb1e6c81f0468a852f946722555b4fbc8eeff7481f3";a:4:{s:10:"expiration";i:1554075623;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36";s:5:"login";i:1552866023;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '183'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:21:"add-post-type-product";i:1;s:12:"add-post_tag";i:2;s:20:"add-new_product_type";}'),
(20, 1, 'nav_menu_recently_edited', '2'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1551070749'),
(23, 1, 'closedpostboxes_product', 'a:0:{}'),
(24, 1, 'metaboxhidden_product', 'a:0:{}'),
(25, 2, 'nickname', 'Rob'),
(26, 2, 'first_name', 'Rob'),
(27, 2, 'last_name', 'H.'),
(28, 2, 'description', ''),
(29, 2, 'rich_editing', 'true'),
(30, 2, 'syntax_highlighting', 'true'),
(31, 2, 'comment_shortcuts', 'false'),
(32, 2, 'admin_color', 'fresh'),
(33, 2, 'use_ssl', '0'),
(34, 2, 'show_admin_bar_front', 'true'),
(35, 2, 'locale', ''),
(36, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(37, 2, 'wp_user_level', '10'),
(38, 2, 'dismissed_wp_pointers', 'wp496_privacy') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'SparkleWolf17', '$P$BhPibzQEZUdUvpTOpdUEl3p0r3ug4l.', 'sparklewolf17', 'stephanie133.tait@gmail.com', '', '2019-02-20 21:47:20', '1550956260:$P$BFtbfQaBHFOMCfcrRJLy3QUqycUUno.', 0, 'SparkleWolf17'),
(2, 'Rob', '$P$B87.Rhzu631SY8gG/bTo3zeFJfW6dV/', 'rob', 'dev@redacademy.com', 'http://Dev', '2019-03-19 04:06:02', '1552968363:$P$BAhhNpWkPxhy234kN5Edz24mHCSdie.', 0, 'Rob H.') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

